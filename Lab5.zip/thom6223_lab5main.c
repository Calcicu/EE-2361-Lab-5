/* 
 * File:   thom6223_lab5main.c
 * Author: Jake Thompson and Carol Svare
 *
 * Created on November 2, 2017, 11:45 AM
 */

#include "p24Fxxxx.h"
#include <xc.h>
#include "lcdLib.h"

// CONFIG2
#pragma config POSCMOD = NONE           // Primary Oscillator Select (Primary oscillator disabled)
#pragma config I2C1SEL = PRI            // I2C1 Pin Location Select (Use default SCL1/SDA1 pins)
#pragma config IOL1WAY = OFF            // IOLOCK Protection (IOLOCK may be changed via unlocking seq)
#pragma config OSCIOFNC = OFF           // Primary Oscillator Output Function (OSC2/CLKO/RC15 functions as CLKO (FOSC/2))
#pragma config FCKSM = CSECME           // Clock Switching and Monitor (Clock switching is enabled, Fail-Safe Clock Monitor is enabled)
#pragma config FNOSC = FRCPLL           // Oscillator Select (Fast RC Oscillator with PLL module (FRCPLL))
#pragma config SOSCSEL = SOSC           // Sec Oscillator Select (Default Secondary Oscillator (SOSC))
#pragma config WUTSEL = LEG             // Wake-up timer Select (Legacy Wake-up Timer)
#pragma config IESO = ON                // Internal External Switch Over Mode (IESO mode (Two-Speed Start-up) enabled)

// CONFIG1
#pragma config WDTPS = PS32768          // Watchdog Timer Postscaler (1:32,768)
#pragma config FWPSA = PR128            // WDT Prescaler (Prescaler ratio of 1:128)
#pragma config WINDIS = ON              // Watchdog Timer Window (Standard Watchdog Timer enabled,(Windowed-mode is disabled))
#pragma config FWDTEN = OFF             // Watchdog Timer Enable (Watchdog Timer is disabled)
#pragma config ICS = PGx1               // Comm Channel Select (Emulator EMUC1/EMUD1 pins are shared with PGC1/PGD1)
#pragma config GWRP = OFF               // General Code Segment Write Protect (Writes to program memory are allowed)
#pragma config GCP = OFF                // General Code Segment Code Protect (Code protection is disabled)
#pragma config JTAGEN = OFF             // JTAG Port Enable (JTAG port is disabled)



void setup(void);

int main(void) {
    int i = 0;
    
    setup();
    lcd_init();
    lcdPrintStr("Hello World!");
    while(1){
        for(i = 0; i < 16; i++){
            lcd_cmd(0b00011100);        //shift display right
            waitms(200);
        }
        for(i = 0; i < 16; i++){
            lcd_cmd(0b00011000);        //shift display left
            waitms(200);
        }
    }
    return (0);
}

void setup(void){
    CLKDIVbits.RCDIV = 0;           // Set RCDIV=1:1 (default 2:1) 32MHz or FCY/2=16M
    AD1PCFG = 0x9fff;               // Set all pins to "digital" mode
    TRISA = 0b1111111111111110;     // Set I/O port A to outputs
    TRISB = 0b0000000000000011;     // Set I/O port B to outputs
    LATA = 1;
    
    I2C2CON = 0;
    I2C2CONbits.DISSLW = 1;         //Disable slew rate control
    I2C2BRG = 157;                  //Set Fscl to 100KHz
    _MI2C2IF = 0;                   //Clear flag
    I2C2CONbits.I2CEN = 1;          //Enable I2C2 module
}